package protogame.game;

import com.badlogic.gdx.Game;

import protogame.screens.Splash;

public class Protogame extends Game {

	@Override
	public void create() {
		setScreen(new Splash(this));
	}

	public void dispose() {
		super.dispose();
	}

	public void render() {
		super.render();
	}

	public void resize(int width, int height) {
		super.resize(width, height);
	}

	public void pause() {
		super.pause();
	}

	public void resume() {
		super.resume();
	}

}
