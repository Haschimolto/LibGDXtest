package protogame.screens;

import com.badlogic.gdx.Application.ApplicationType;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.ChainShape;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.utils.Array;

import protogame.entities.Player;
import protogame.game.LevelGenerator;

public class GameScreen3 implements Screen {
	private int level;
	private Game game;
	private World world;
	private Box2DDebugRenderer debugRenderer;
	private SpriteBatch batch;
	private OrthographicCamera cam;

	private final float TIMESTEP = 1 / 60f;
	private final int VELOCITYITERATIONS = 8, POSITIONITERATIONS = 3;

	private LevelGenerator levelGenerator;
	private Player player;
	private Body ground;

	private Vector3 bottomLeft, bottomRight;

	private Array<Body> tmpBodies = new Array<Body>();

	public GameScreen3(Game game, int level) {
		this.game = game;
		this.level = level;
	}

	@Override
	public void show() {
		if (Gdx.app.getType() == ApplicationType.Desktop)
			Gdx.graphics.setWindowedMode(512, Gdx.graphics.getHeight());
		world = new World(new Vector2(0, -9.81f), true);
		debugRenderer = new Box2DDebugRenderer();
		batch = new SpriteBatch();

		cam = new OrthographicCamera(Gdx.graphics.getWidth() / 25, Gdx.graphics.getHeight() / 25);

		player = new Player(world, 0, 1, 1);
		// giving Player a texture, maybe do it in his class?
		Sprite boxSprite = new Sprite(new Texture("man1.png"));
		boxSprite.setSize(1, 2);
		player.getBody().setUserData(boxSprite);
		world.setContactFilter(player);
		world.setContactListener(player);

		Gdx.input.setInputProcessor(new InputMultiplexer(new InputAdapter() {
			public boolean keyDown(int keycode) {
				switch (keycode) {
				case Keys.ESCAPE:
					game.setScreen(new Levels(game));
					break;
				}
				return false;
			}

			@Override
			public boolean scrolled(float amountX, float amountY) {
				cam.zoom += amountY / 25f;
				return true;
			}
		}, player));

		BodyDef bodyDef = new BodyDef();
		FixtureDef fixtureDef = new FixtureDef();

		// GROUND
		// body definition
		bodyDef.type = BodyType.StaticBody;
		bodyDef.position.set(0, 0);

		// ground shape
		ChainShape groundShape = new ChainShape();
		// creating vectors for the limits of the playing field
		bottomLeft = new Vector3(0, Gdx.graphics.getHeight(), 0);
		bottomRight = new Vector3(Gdx.graphics.getWidth() + 1, bottomLeft.y, 0);
		// converting vector window coordinates to world coordinates
		cam.unproject(bottomLeft);
		cam.unproject(bottomRight);
		groundShape.createChain(new float[] { bottomLeft.x, bottomLeft.y, bottomRight.x, bottomRight.y });

		// fixture definition
		fixtureDef.shape = groundShape;
		fixtureDef.friction = 0.5f;
		fixtureDef.restitution = 0;

		ground = world.createBody(bodyDef);
		ground.createFixture(fixtureDef);

//		// create a platform for testing
//		groundShape = new ChainShape();
//		groundShape.createChain(new float[] { bottomRight.x - 8, 2, bottomRight.x - 4, 2 });

		world.createBody(bodyDef).createFixture(groundShape, 0);

		groundShape.dispose();

		levelGenerator = new LevelGenerator(ground, bottomLeft.x, bottomRight.x, player.width, player.height * 3,
				player.width * 1.5f, player.width * 3.f, player.width / 3, 20 * MathUtils.degRad);

	}

	@Override
	public void render(float delta) {
		Gdx.gl.glClearColor(0, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

		if (player.getBody().getPosition().x < bottomLeft.x)
			player.getBody().setTransform(bottomRight.x, player.getBody().getPosition().y, player.getBody().getAngle());
		else if (player.getBody().getPosition().x > bottomRight.x)
			player.getBody().setTransform(bottomLeft.x, player.getBody().getPosition().y, player.getBody().getAngle());
		player.update();
		world.step(TIMESTEP, VELOCITYITERATIONS, POSITIONITERATIONS);

		// center cam on box
		cam.position.y = player.getBody().getPosition().y > cam.position.y ? player.getBody().getPosition().y
				: cam.position.y;
		cam.update();

		batch.setProjectionMatrix(cam.combined);
		batch.begin();
		world.getBodies(tmpBodies);
		for (Body body : tmpBodies)
			if (body.getUserData() != null && body.getUserData() instanceof Sprite) {
				Sprite sprite = (Sprite) body.getUserData();
				sprite.setPosition(body.getPosition().x - sprite.getWidth() / 2,
						body.getPosition().y - sprite.getHeight() / 2);
				sprite.setRotation(body.getAngle() * MathUtils.radiansToDegrees);
				sprite.draw(batch);
			}
		batch.end();

		debugRenderer.render(world, cam.combined);

		levelGenerator.generate(cam.position.y + cam.viewportHeight / 2);

	}

	@Override
	public void resize(int width, int height) {
		cam.viewportWidth = width / 25;
		cam.viewportHeight = height / 25;
		// not needed because updating is done in render method
//		cam.update();

	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub

	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub

	}

	@Override
	public void hide() {
		dispose();
	}

	@Override
	public void dispose() {
		world.dispose();
		debugRenderer.dispose();
	}

}
