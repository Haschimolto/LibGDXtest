package protogame.screens;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.ChainShape;
import com.badlogic.gdx.physics.box2d.CircleShape;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.physics.box2d.joints.DistanceJointDef;
import com.badlogic.gdx.physics.box2d.joints.RopeJointDef;
import com.badlogic.gdx.utils.Array;

import protogame.game.InputController;

public class GameScreen implements Screen {
	private int level;
	private Game game;
	private World world;
	private Box2DDebugRenderer debugRenderer;
	private SpriteBatch batch;
	private OrthographicCamera cam;

	private final float TIMESTEP = 1 / 60f;
	private final int VELOCITYITERATIONS = 8, POSITIONITERATIONS = 3;

	private float speed = 500;
	private Vector2 movement = new Vector2();
	private Body box;

	private Sprite boxSprite;

	private Array<Body> tmpBodies = new Array<Body>();

	public GameScreen(Game game, int level) {
		this.game = game;
		this.level = level;
	}

	@Override
	public void show() {
		world = new World(new Vector2(0, -9.81f), true);
		debugRenderer = new Box2DDebugRenderer();
		batch = new SpriteBatch();

		cam = new OrthographicCamera();

		Gdx.input.setInputProcessor(new InputController() {
			public boolean keyDown(int keycode) {
				switch (keycode) {
				case Keys.ESCAPE:
					game.setScreen(new Levels(game));
					break;
				case Keys.W:
					movement.y = speed;
					break;
				case Keys.A:
					movement.x = -speed;
					break;
				case Keys.S:
					movement.y = -speed;
					break;
				case Keys.D:
					movement.x = speed;
				}
				return true;
			}

			public boolean keyUp(int keycode) {
				switch (keycode) {
				case Keys.W:
				case Keys.S:
					movement.y = 0;
					break;
				case Keys.A:
				case Keys.D:
					movement.x = 0;
				}
				return true;
			}

			@Override
			public boolean scrolled(float amountX, float amountY) {
				cam.zoom += amountY / 25f;
				return true;
			}
		});

		BodyDef bodyDef = new BodyDef();
		FixtureDef fixtureDef = new FixtureDef();

		// BOX
		// body definition
		bodyDef.type = BodyType.DynamicBody;
		bodyDef.position.set(2.25f, 10);

		// box shape
		PolygonShape boxShape = new PolygonShape();
		boxShape.setAsBox(.5f, 1);

		// fixture definition
		fixtureDef.shape = boxShape;
		fixtureDef.friction = 0.75f;
		fixtureDef.restitution = .1f;
		fixtureDef.density = 5;

		box = world.createBody(bodyDef);
		box.createFixture(fixtureDef);

		boxSprite = new Sprite(new Texture("man1.png"));
		boxSprite.setSize(1, 2);
		// alternative way
		// boxSprite.setOrigin(boxSprite.getWidth() / 2, boxSprite.getHeight() / 2);
		boxSprite.setOriginCenter();
		box.setUserData(boxSprite);

		boxShape.dispose();

		// BALL
		// ball shape
		CircleShape ballShape = new CircleShape();
		ballShape.setPosition(new Vector2(0, 1.5f));
		ballShape.setRadius(0.5f);

		// fixture definition
		fixtureDef.shape = ballShape;
		fixtureDef.density = 2.5f;
		fixtureDef.friction = 0.25f;
		fixtureDef.restitution = 0.75f;

		box.createFixture(fixtureDef);
		ballShape.dispose();

		// GROUND
		// body definition
		bodyDef.type = BodyType.StaticBody;
		bodyDef.position.set(0, 0);

		// ground shape
		ChainShape groundShape = new ChainShape();
		groundShape.createChain(new Vector2[] { new Vector2(-50, 0), new Vector2(50, 0) });

		// fixture definition
		fixtureDef.shape = groundShape;
		fixtureDef.friction = 0.5f;
		fixtureDef.restitution = 0;

		Body ground = world.createBody(bodyDef);
		ground.createFixture(fixtureDef);
		// other box
		bodyDef.position.y = 7;

		PolygonShape otherBoxShape = new PolygonShape();
		otherBoxShape.setAsBox(0.25f, 0.25f);

		fixtureDef.shape = otherBoxShape;

		Body otherBox = world.createBody(bodyDef);
		otherBox.createFixture(fixtureDef);

		otherBoxShape.dispose();

		// Distance Joint between other box and box
		DistanceJointDef distanceJointDef = new DistanceJointDef();
		distanceJointDef.bodyA = otherBox;
		distanceJointDef.bodyB = box;
		distanceJointDef.length = 5;

		world.createJoint(distanceJointDef);

		// RopeJoint between ground and box
		RopeJointDef ropeJointDef = new RopeJointDef();
		ropeJointDef.bodyA = ground;
		ropeJointDef.bodyB = box;
		ropeJointDef.maxLength = 4;
		ropeJointDef.localAnchorA.set(0, 0);
		ropeJointDef.localAnchorB.set(0, 0);

		world.createJoint(ropeJointDef);

		groundShape.dispose();
	}

	@Override
	public void render(float delta) {
		Gdx.gl.glClearColor(0, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

		// poll based input solution
//		if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
//			movement.x = -speed;
//		} else if (Gdx.input.isKeyPressed(Input.Keys.RIGHT))
//			movement.x = speed;
//		else
//			movement.x = 0;
//		if (Gdx.input.isKeyPressed(Input.Keys.UP))
//			movement.y = speed;
//		else if (Gdx.input.isKeyPressed(Input.Keys.DOWN))
//			movement.y = -speed;
//		else
//			movement.y = 0;

		world.step(TIMESTEP, VELOCITYITERATIONS, POSITIONITERATIONS);
		box.applyForceToCenter(movement, true);

		// center cam on box
		cam.position.set(box.getPosition().x, box.getPosition().y, 0);
		cam.update();

		batch.setProjectionMatrix(cam.combined);
		batch.begin();
		world.getBodies(tmpBodies);
		for (Body body : tmpBodies)
			if (body.getUserData() != null && body.getUserData() instanceof Sprite) {
				Sprite sprite = (Sprite) body.getUserData();
				sprite.setPosition(body.getPosition().x - sprite.getWidth() / 2,
						body.getPosition().y - sprite.getHeight() / 2);
				sprite.setRotation(body.getAngle() * MathUtils.radiansToDegrees);
				sprite.draw(batch);
			}
		batch.end();

		debugRenderer.render(world, cam.combined);

	}

	@Override
	public void resize(int width, int height) {
		cam.viewportWidth = width / 25;
		cam.viewportHeight = height / 25;
		// not needed because updating is done in render method
//		cam.update();

	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub

	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub

	}

	@Override
	public void hide() {
		dispose();
	}

	@Override
	public void dispose() {
		world.dispose();
		debugRenderer.dispose();
		boxSprite.getTexture().dispose();
	}

}
