package tutorials;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Animation.PlayMode;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureAtlas.AtlasRegion;

public class SimpleAnimation implements ApplicationListener {
	private SpriteBatch batch;
	private TextureAtlas textureAtlas;
	Animation<AtlasRegion> animation;
	private float elapsedTime = 0;
	private int xOffset = 0;
	private int yOffset = 0;
	private int xMove = 1;
	private int yMove = 1;

	@Override
	public void create() {
		batch = new SpriteBatch();
		textureAtlas = new TextureAtlas("tutorial/spritesheet.atlas");
		animation = new Animation<AtlasRegion>(1 / 15f, textureAtlas.getRegions(), PlayMode.LOOP);

	}

	@Override
	public void dispose() {
		batch.dispose();
		textureAtlas.dispose();
	}

	@Override
	public void render() {
		Gdx.gl.glClearColor(0, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		// bouncing the sprite inside the screen
		if (xOffset >= Gdx.graphics.getWidth() - 256 || xOffset < 0) {
			xMove *= -1;
		}
		if (yOffset >= Gdx.graphics.getHeight() - 128 || yOffset < 0) {
			yMove *= -1;
		}

		xOffset += xMove;
		yOffset += yMove;

		batch.begin();
		elapsedTime += Gdx.graphics.getDeltaTime();
		batch.draw(animation.getKeyFrame(elapsedTime), xOffset, yOffset);
		batch.end();
	}

	@Override
	public void resize(int width, int height) {
	}

	@Override
	public void pause() {
	}

	@Override
	public void resume() {
	}
}