package tutorials;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.Texture.TextureFilter;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class CameraBasics implements ApplicationListener {
	private OrthographicCamera cam;
	private SpriteBatch batch;
	private Texture texture;
	private Sprite sprite;
	private float time;

	@Override
	public void create() {
		cam = new OrthographicCamera(640, 480);
		batch = new SpriteBatch();

		texture = new Texture("tutorial/large.jpg");
		texture.setFilter(TextureFilter.Linear, TextureFilter.Linear);

		sprite = new Sprite(texture);
		sprite.setOrigin(0, 0);
		sprite.setPosition(-sprite.getWidth() / 2, -sprite.getHeight() / 2);

	}

	@Override
	public void resize(int width, int height) {
		// TODO Auto-generated method stub

	}

	@Override
	public void render() {
		time += Gdx.graphics.getDeltaTime();
		float maxY = sprite.getHeight() / 2 - cam.viewportHeight / 2;
		float maxX = sprite.getWidth() / 2 - cam.viewportWidth / 2;
		if (time > 1) {
			System.out.println(cam.position.x + ", " + cam.position.y);
			time = 0;
		}
		if (Gdx.input.isKeyPressed(Input.Keys.UP)) {
			if (cam.position.y < maxY) {
				if (Gdx.input.isKeyPressed(Input.Keys.CONTROL_LEFT))
					cam.translate(0, 10);
				else
					cam.translate(0, 1);
			}
		}
		if (Gdx.input.isKeyPressed(Input.Keys.DOWN)) {
			if (cam.position.y > -maxY) {
				if (Gdx.input.isKeyPressed(Input.Keys.CONTROL_LEFT))
					cam.translate(0, -10);
				else
					cam.translate(0, -1);
			}
		}
		if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
			if (cam.position.x > -maxX)
				cam.translate(-10, 0);
		}
		if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
			if (cam.position.x < maxX)
				cam.translate(10, 0);
		}
		cam.update();
		Gdx.gl.glClearColor(1, 1, 1, 1);

		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

		batch.setProjectionMatrix(cam.combined);

		batch.begin();
		sprite.draw(batch);
		batch.end();

	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub

	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose() {
		batch.dispose();
		texture.dispose();

	}

}
