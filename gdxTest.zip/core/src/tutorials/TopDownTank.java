package tutorials;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.utils.Array;

import protogame.screens.Levels;

public class TopDownTank implements Screen {

	private Game game;
	private World world;
	private Box2DDebugRenderer debugRenderer;
	private SpriteBatch batch;
	private OrthographicCamera cam;
	private Texture test;
	private Sprite tankSprite;

	private final float timestep = 1 / 60f;

	private Tank tank;
	private Array<Body> tmpBodies = new Array<Body>();

	public TopDownTank(Game game) {
		this.game = game;
	}

	@Override
	public void show() {
		debugRenderer = new Box2DDebugRenderer();
		world = new World(new Vector2(), true);
		batch = new SpriteBatch();
		cam = new OrthographicCamera();
		test = new Texture("man1.png");

		tankSprite = new Sprite(new Texture("tutorial/jet.png"));
		tankSprite.setSize(3, 5);
		// alternative way
		// boxSprite.setOrigin(boxSprite.getWidth() / 2, boxSprite.getHeight() / 2);
		tankSprite.setOriginCenter();

		Gdx.input.setInputProcessor(new InputMultiplexer(new InputAdapter() {
			public boolean keyDown(int keycode) {
				switch (keycode) {
				case Keys.ESCAPE:
					game.setScreen(new Levels(game));
					break;
				}
				return false;
			}

			@Override
			public boolean scrolled(float amountX, float amountY) {
				cam.zoom += amountY / 25f;
				return true;
			}
		}, tank = new Tank(world, 0, 0, 3, 5)));
//		Gdx.input.setInputProcessor(tank = new Tank(world, 0, 0, 3, 5));
		tank.getChassis().setLinearDamping(3);
		tank.getChassis().setAngularDamping(3);
		tank.getCannon().setLinearDamping(3);
		tank.getCannon().setAngularDamping(3);

		tank.getChassis().setUserData(tankSprite);
	}

	@Override
	public void render(float delta) {
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

		tank.update();
		world.step(timestep, 8, 3);
		cam.position.set(tank.getChassis().getPosition().x, tank.getChassis().getPosition().y, 0);
		cam.update();

		batch.setProjectionMatrix(cam.combined);
		batch.begin();
		batch.draw(test, -test.getWidth() / 2, -test.getHeight() / 2);
		world.getBodies(tmpBodies);
		for (Body body : tmpBodies)
			if (body.getUserData() != null && body.getUserData() instanceof Sprite) {
				Sprite sprite = (Sprite) body.getUserData();
				sprite.setPosition(body.getPosition().x - sprite.getWidth() / 2,
						body.getPosition().y - sprite.getHeight() / 2);
				sprite.setRotation(body.getAngle() * MathUtils.radiansToDegrees);
				sprite.draw(batch);
			}
		batch.end();

		debugRenderer.render(world, cam.combined);

	}

	@Override
	public void resize(int width, int height) {
		cam.viewportWidth = width / 25;
		cam.viewportHeight = height / 25;

	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub

	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub

	}

	@Override
	public void hide() {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose() {
		world.dispose();
		batch.dispose();
		debugRenderer.dispose();
	}

}
