package tutorials;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class MultipleAnimations implements ApplicationListener {
	SpriteBatch batch;
	TextureAtlas textureAtlas;
	Animation<TextureRegion> rotateUpAnimation, rotateDownAnimation;
	private float elapsedTime = 0;

	@Override
	public void create() {
		batch = new SpriteBatch();
		textureAtlas = new TextureAtlas("tutorial/spritesheet.atlas");

		TextureRegion[] rotateUpFrames = new TextureRegion[10];

		// Rotate Up Animation
		// Create an array of TextureRegions
		for (int i = 0; i < 9; i++) {
			rotateUpFrames[i] = (textureAtlas.findRegion("000" + (i + 1)));
		}
		rotateUpFrames[9] = (textureAtlas.findRegion("0010"));
		rotateUpAnimation = new Animation<TextureRegion>(0.1f, rotateUpFrames);

		// Rotate Down Animation
		// Or you can just pass in all of the regions to the Animation constructor
		rotateDownAnimation = new Animation<TextureRegion>(0.1f, (textureAtlas.findRegion("0011")),
				(textureAtlas.findRegion("0012")), (textureAtlas.findRegion("0013")), (textureAtlas.findRegion("0014")),
				(textureAtlas.findRegion("0015")), (textureAtlas.findRegion("0016")), (textureAtlas.findRegion("0017")),
				(textureAtlas.findRegion("0018")), (textureAtlas.findRegion("0019")),
				(textureAtlas.findRegion("0020")));
	}

	@Override
	public void resize(int width, int height) {
		// TODO Auto-generated method stub

	}

	@Override
	public void render() {
		Gdx.gl.glClearColor(0, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

		batch.begin();
		elapsedTime += Gdx.graphics.getDeltaTime();
		batch.draw(rotateDownAnimation.getKeyFrame(elapsedTime, true), 0, 0);
		batch.draw(rotateUpAnimation.getKeyFrame(elapsedTime, true), 300, 0);
		batch.end();

	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub

	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub

	}

}
