package tutorials;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.Touchable;

public class Scenebuilding implements ApplicationListener {

	public class MyActor extends Actor {
		Texture texture;
		float actorX, actorY;
		public boolean started = false;

		public void draw(Batch batch, float alpha) {
			batch.draw(texture, actorX, actorY);
		}

		public MyActor(String imagepath, float x, float y) {
			texture = new Texture(imagepath);
			actorX = x;
			actorY = y;
			setBounds(actorX, actorY, texture.getWidth(), texture.getHeight());
			setTouchable(Touchable.enabled);

			// anonymous inner class
			addListener(new InputListener() {
				public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
					System.out.println("touched" + actorY);
					((MyActor) event.getTarget()).started = true;
					return true;
				}
			});

		}

		@Override
		public void act(float delta) {
			if (started) {
				actorX += 5;
			}
		}
	}

	private Stage stage;

	@Override
	public void create() {
		stage = new Stage();
		Gdx.input.setInputProcessor(stage);
		MyActor actor = new MyActor("tutorial/jet.png", 0, 0);
		MyActor actor2 = new MyActor("tutorial/shot.jpg", 0, 300);

		stage.addActor(actor);
		stage.addActor(actor2);
		stage.setDebugAll(true);

	}

	@Override
	public void resize(int width, int height) {
		// TODO Auto-generated method stub

	}

	@Override
	public void render() {
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		stage.draw();
		stage.act();

	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub

	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose() {
		stage.dispose();
	}

}
