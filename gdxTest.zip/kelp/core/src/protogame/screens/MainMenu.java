package protogame.screens;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton.TextButtonStyle;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

public class MainMenu implements Screen {
	Game game;
	private Stage stage;
	private Skin skin;
	private Table table;

	public MainMenu(Game game) {
		this.game = game;
	}

	@Override
	public void show() {
		// ScreenVP so Actors on Screen dont get stretched on resolution changes
		ScreenViewport sv = new ScreenViewport();
		stage = new Stage(sv);
		Gdx.input.setInputProcessor(stage);
		// instead of textureAtlas I just add different TextureRegions for simplicity
		skin = new Skin();
		TextureRegion b1 = new TextureRegion(new Texture("tutorial/button.jpg"));
		TextureRegion b2 = new TextureRegion(new Texture("tutorial/button2.jpg"));
		skin.add("button1", b1);
		skin.add("button2", b2);
		table = new Table(skin);
		table.setFillParent(true);
		table.setBounds(0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
		TextButtonStyle textButtonStyle = new TextButtonStyle();
		// setting graphics for pressed and unpressed, hover and more are possible
		textButtonStyle.up = skin.getDrawable("button1");
		textButtonStyle.down = skin.getDrawable("button2");
		textButtonStyle.pressedOffsetX = 1;
		textButtonStyle.pressedOffsetY = -1;
		// used this instead of creating an extra variable for the font
		textButtonStyle.font = new BitmapFont();
		textButtonStyle.fontColor = Color.BLACK;

		TextButton buttonExit = new TextButton("exit", textButtonStyle);
		buttonExit.getLabel().setFontScale(1.2f);
		buttonExit.addListener(new ClickListener() {
			@Override
			public void clicked(InputEvent event, float x, float y) {
				Gdx.app.exit();
			}
		});
		// buttonExit.pad(20);

		TextButton buttonPlay = new TextButton("play", textButtonStyle);
		buttonPlay.getLabel().setFontScale(1.2f);
		buttonPlay.addListener(new ClickListener() {
			@Override
			public void clicked(InputEvent event, float x, float y) {
				game.setScreen(new Levels(game));
			}
		});

		// Heading
		Label heading = new Label("Protogame", new LabelStyle(new BitmapFont(), Color.WHITE));
		heading.setFontScale(2f);

		table.add(heading);
		table.getCell(heading).spaceBottom(50);
		table.row();
		table.add(buttonPlay);
		table.getCell(buttonPlay).spaceBottom(5);
		table.row();
		table.add(buttonExit);
		table.debug();
		stage.addActor(table);

	}

	@Override
	public void render(float delta) {
		Gdx.gl.glClearColor(0, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		stage.act(delta);
		stage.draw();

	}

	@Override
	public void resize(int width, int height) {
		stage.getViewport().update(width, height, true);
//		table.setTransform(true);
//		table.setSize(width, height);
//		table.invalidateHierarchy();

	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub

	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub

	}

	@Override
	public void hide() {
		Gdx.input.setInputProcessor(null);
		dispose();

	}

	@Override
	public void dispose() {
		stage.dispose();
		skin.dispose();

	}

}
