package tutorials;

//import com.badlogic.gdx.scenes.scene2d.actions.MoveToAction;
//import com.badlogic.gdx.scenes.scene2d.actions.RotateToAction;
//import com.badlogic.gdx.scenes.scene2d.actions.ScaleToAction;
//import com.badlogic.gdx.scenes.scene2d.actions.SequenceAction;
import static com.badlogic.gdx.scenes.scene2d.actions.Actions.moveTo;
import static com.badlogic.gdx.scenes.scene2d.actions.Actions.rotateTo;
import static com.badlogic.gdx.scenes.scene2d.actions.Actions.run;
import static com.badlogic.gdx.scenes.scene2d.actions.Actions.scaleTo;
import static com.badlogic.gdx.scenes.scene2d.actions.Actions.sequence;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;

public class ActionsDemo implements ApplicationListener {

	public class MyActor extends Actor {
		Texture texture = new Texture("tutorial/jet.png");
		public boolean started = false;

		public MyActor() {
			setBounds(getX(), getY(), texture.getWidth(), texture.getHeight());
		}

		@Override
		public void draw(Batch batch, float alpha) {
			batch.draw(texture, this.getX(), getY(), this.getOriginX(), this.getOriginY(), this.getWidth(),
					this.getHeight(), this.getScaleX(), this.getScaleY(), this.getRotation(), 0, 0, texture.getWidth(),
					texture.getHeight(), false, false);
		}
	}

	private Stage stage;

	@Override
	public void create() {
		stage = new Stage();
		Gdx.input.setInputProcessor(stage);

		final MyActor myActor = new MyActor();
		// does the same as codeblock below it
		myActor.addAction(
				sequence(scaleTo(0.5f, 0.5f, 5f), rotateTo(90.0f, 5f), moveTo(300.0f, 0f, 5f), run(new Runnable() {
					public void run() {
						System.out.println("donezo");
					}
				})));

//		SequenceAction sequenceAction = new SequenceAction();
//		MoveToAction moveAction = new MoveToAction();
//		moveAction.setPosition(300f, 0f);
//		moveAction.setDuration(5f);
//
//		RotateToAction rotateAction = new RotateToAction();
//		rotateAction.setRotation(90f);
//		rotateAction.setDuration(5f);
//
//		ScaleToAction scaleAction = new ScaleToAction();
//		scaleAction.setScale(0.5f);
//		scaleAction.setDuration(5f);
//		sequenceAction.addAction(scaleAction);
//		sequenceAction.addAction(rotateAction);
//		sequenceAction.addAction(moveAction);
//		myActor.addAction(sequenceAction);

		stage.addActor(myActor);
	}

	@Override
	public void dispose() {
		stage.dispose();
	}

	@Override
	public void render() {
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		stage.act(Gdx.graphics.getDeltaTime());
		stage.draw();
	}

	@Override
	public void resize(int width, int height) {
	}

	@Override
	public void pause() {
	}

	@Override
	public void resume() {

	}
}