package tutorials;

import static com.badlogic.gdx.scenes.scene2d.actions.Actions.moveTo;
import static com.badlogic.gdx.scenes.scene2d.actions.Actions.parallel;
import static com.badlogic.gdx.scenes.scene2d.actions.Actions.rotateBy;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Group;
import com.badlogic.gdx.scenes.scene2d.Stage;

public class Grouping implements ApplicationListener {

	private Stage stage;
	private Group group;

	@Override
	public void create() {
		stage = new Stage();

		class MyActor extends Actor {
			TextureRegion texture;

			MyActor(TextureRegion texture) {
				super();
				this.texture = texture;
			}

			// Overriding default draw to show rotation and scale as well
			public void draw(Batch batch, float alpha) {
				batch.draw(texture, getX(), getY(), getOriginX(), getOriginY(), getWidth(), getHeight(), getScaleX(),
						getScaleY(), getRotation());
			}
		}

		final MyActor jet = new MyActor(new TextureRegion(new Texture("tutorial/jet.png")));
		jet.setBounds(jet.getX(), jet.getY(), jet.texture.getRegionWidth(), jet.texture.getRegionHeight());

		final MyActor flame = new MyActor(new TextureRegion(new Texture("tutorial/flame.png")));
		flame.setBounds(0, 0, flame.texture.getRegionWidth(), flame.texture.getRegionHeight());
		flame.setPosition(jet.getWidth() - 40, 80);

		group = new Group();
		group.addActor(jet);
		group.addActor(flame);

		group.addAction(parallel(moveTo(200, 0, 5), rotateBy(90, 5)));

		stage.addActor(group);

	}

	@Override
	public void dispose() {
		stage.dispose();
	}

	@Override
	public void render() {
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		stage.act(Gdx.graphics.getDeltaTime());
		stage.draw();
	}

	@Override
	public void resize(int width, int height) {
	}

	@Override
	public void pause() {
	}

	@Override
	public void resume() {
	}
}
