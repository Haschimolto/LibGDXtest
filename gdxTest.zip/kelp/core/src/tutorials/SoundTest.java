package tutorials;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;

public class SoundTest implements ApplicationListener {
	Music wavSound;
	float time;

	@Override
	public void create() {
		wavSound = Gdx.audio.newMusic(Gdx.files.internal("tutorial/song1.mp3"));
		wavSound.setLooping(true);
		wavSound.setVolume(0.2f); // 0-100% volume
		wavSound.play();

	}

	@Override
	public void resize(int width, int height) {
		// TODO Auto-generated method stub

	}

	@Override
	public void render() {
		time += Gdx.graphics.getDeltaTime();
		// pausing and playing every 2 seconds alternating
		if (time > 2) {
			wavSound.pause();
		}
		if (time > 4) {
			wavSound.play();
			time = 0;
		}

	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub

	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose() {
		wavSound.dispose();

	}

}
